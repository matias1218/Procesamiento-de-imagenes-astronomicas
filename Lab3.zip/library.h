//------------------------------------------IMPORTACION DE LIBRERIAS----------------------------------------------//

/* Este es el achivo que almacena las librerias ocupadas por el programa */
#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <math.h>
#include <unistd.h>
#include <pthread.h> 
#include "header.h"
#include "functions.c"

//-----------------------------------------------------------------------------------------------------------------//
